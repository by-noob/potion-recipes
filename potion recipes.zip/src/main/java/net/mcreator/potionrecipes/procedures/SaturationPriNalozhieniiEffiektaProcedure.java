package net.mcreator.potionrecipes.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.potionrecipes.init.PotionRecipesModMobEffects;

public class SaturationPriNalozhieniiEffiektaProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.SATURATION,
					entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(PotionRecipesModMobEffects.SATURATION.get()) ? _livEnt.getEffect(PotionRecipesModMobEffects.SATURATION.get()).getDuration() : 0, 1));
	}
}
