
package net.mcreator.potionrecipes.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class PrismaxtureItem extends Item {
	public PrismaxtureItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
