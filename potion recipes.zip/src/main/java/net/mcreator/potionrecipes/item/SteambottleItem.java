
package net.mcreator.potionrecipes.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;

import net.mcreator.potionrecipes.procedures.SteambottlePriUdariePoSushchnostiPriedmietomProcedure;

public class SteambottleItem extends Item {
	public SteambottleItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		SteambottlePriUdariePoSushchnostiPriedmietomProcedure.execute(entity, sourceentity);
		return retval;
	}
}
