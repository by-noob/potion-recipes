
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.potionrecipes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.potionrecipes.item.WhizzbangshulkerbottleItem;
import net.mcreator.potionrecipes.item.SteambottleItem;
import net.mcreator.potionrecipes.item.PrismaxtureItem;
import net.mcreator.potionrecipes.item.NetherbonemealItem;
import net.mcreator.potionrecipes.item.MixtureofheartsItem;
import net.mcreator.potionrecipes.item.HastemixtureItem;
import net.mcreator.potionrecipes.PotionRecipesMod;

public class PotionRecipesModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, PotionRecipesMod.MODID);
	public static final RegistryObject<Item> NETHERBONEMEAL = REGISTRY.register("netherbonemeal", () -> new NetherbonemealItem());
	public static final RegistryObject<Item> SMOKEBOTTLE = REGISTRY.register("smokebottle", () -> new SteambottleItem());
	public static final RegistryObject<Item> WHIZZBANGSHULKERBOTTLE = REGISTRY.register("whizzbangshulkerbottle", () -> new WhizzbangshulkerbottleItem());
	public static final RegistryObject<Item> HASTEMIXTURE = REGISTRY.register("hastemixture", () -> new HastemixtureItem());
	public static final RegistryObject<Item> PRISMAXTURE = REGISTRY.register("prismaxture", () -> new PrismaxtureItem());
	public static final RegistryObject<Item> MIXTUREOFHEARTS = REGISTRY.register("mixtureofhearts", () -> new MixtureofheartsItem());
}
