
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.potionrecipes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.potionrecipes.PotionRecipesMod;

public class PotionRecipesModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PotionRecipesMod.MODID);
	public static final RegistryObject<CreativeModeTab> POTION_RECIPES = REGISTRY.register("potion_recipes",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.potion_recipes.potion_recipes")).icon(() -> new ItemStack(PotionRecipesModItems.SMOKEBOTTLE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(PotionRecipesModItems.NETHERBONEMEAL.get());
				tabData.accept(PotionRecipesModItems.SMOKEBOTTLE.get());
				tabData.accept(PotionRecipesModItems.WHIZZBANGSHULKERBOTTLE.get());
				tabData.accept(PotionRecipesModItems.HASTEMIXTURE.get());
				tabData.accept(PotionRecipesModItems.PRISMAXTURE.get());
				tabData.accept(PotionRecipesModItems.MIXTUREOFHEARTS.get());
			})

					.build());
}
