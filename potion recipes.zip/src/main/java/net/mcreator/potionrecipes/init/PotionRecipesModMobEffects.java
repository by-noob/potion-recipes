
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.potionrecipes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.potionrecipes.potion.SaturationMobEffect;
import net.mcreator.potionrecipes.PotionRecipesMod;

public class PotionRecipesModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, PotionRecipesMod.MODID);
	public static final RegistryObject<MobEffect> SATURATION = REGISTRY.register("saturation", () -> new SaturationMobEffect());
}
