
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.potionrecipes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.potionrecipes.PotionRecipesMod;

public class PotionRecipesModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, PotionRecipesMod.MODID);
	public static final RegistryObject<Potion> WITHERPOTIONLONG = REGISTRY.register("witherpotionlong", () -> new Potion(new MobEffectInstance(MobEffects.WITHER, 1800, 0, false, true)));
	public static final RegistryObject<Potion> WITHERPOTION = REGISTRY.register("witherpotion", () -> new Potion(new MobEffectInstance(MobEffects.WITHER, 900, 0, false, true)));
	public static final RegistryObject<Potion> WITHERPOTIONENHANCED = REGISTRY.register("witherpotionenhanced", () -> new Potion(new MobEffectInstance(MobEffects.WITHER, 900, 1, false, true)));
	public static final RegistryObject<Potion> GLOWINGPOTION = REGISTRY.register("glowingpotion", () -> new Potion(new MobEffectInstance(MobEffects.GLOWING, 1800, 0, false, true)));
	public static final RegistryObject<Potion> GLOWINGPOTIONLONG = REGISTRY.register("glowingpotionlong", () -> new Potion(new MobEffectInstance(MobEffects.GLOWING, 3600, 0, false, true)));
	public static final RegistryObject<Potion> DARKNESSPOTION = REGISTRY.register("darknesspotion", () -> new Potion(new MobEffectInstance(MobEffects.DARKNESS, 3600, 0, false, true)));
	public static final RegistryObject<Potion> DARKNESSPOTIONLONG = REGISTRY.register("darknesspotionlong", () -> new Potion(new MobEffectInstance(MobEffects.DARKNESS, 7200, 0, false, true)));
	public static final RegistryObject<Potion> HUNGERPOTION = REGISTRY.register("hungerpotion", () -> new Potion(new MobEffectInstance(MobEffects.HUNGER, 1200, 0, false, true)));
	public static final RegistryObject<Potion> HUNGERPOTIONLONG = REGISTRY.register("hungerpotionlong", () -> new Potion(new MobEffectInstance(MobEffects.HUNGER, 2400, 0, false, true)));
	public static final RegistryObject<Potion> HUNGERPOTIONENHANCED = REGISTRY.register("hungerpotionenhanced", () -> new Potion(new MobEffectInstance(MobEffects.HUNGER, 700, 1, false, true)));
	public static final RegistryObject<Potion> BLINDNESSPOTION = REGISTRY.register("blindnesspotion", () -> new Potion(new MobEffectInstance(MobEffects.BLINDNESS, 1200, 0, false, true)));
	public static final RegistryObject<Potion> BLINDNESSPOTIONLONG = REGISTRY.register("blindnesspotionlong", () -> new Potion(new MobEffectInstance(MobEffects.BLINDNESS, 2400, 0, false, true)));
	public static final RegistryObject<Potion> LEVITATIONPOTION = REGISTRY.register("levitationpotion", () -> new Potion(new MobEffectInstance(MobEffects.LEVITATION, 1200, 0, false, true)));
	public static final RegistryObject<Potion> LEVITATIONPOTIONLONG = REGISTRY.register("levitationpotionlong", () -> new Potion(new MobEffectInstance(MobEffects.LEVITATION, 2400, 0, false, true)));
	public static final RegistryObject<Potion> LEVITATIONPOTIONENHANCED = REGISTRY.register("levitationpotionenhanced", () -> new Potion(new MobEffectInstance(MobEffects.LEVITATION, 600, 1, false, true)));
	public static final RegistryObject<Potion> HASTEPOTION = REGISTRY.register("hastepotion", () -> new Potion(new MobEffectInstance(MobEffects.DIG_SPEED, 3600, 0, false, true)));
	public static final RegistryObject<Potion> HASTEPOTIONLONG = REGISTRY.register("hastepotionlong", () -> new Potion(new MobEffectInstance(MobEffects.DIG_SPEED, 7200, 0, false, true)));
	public static final RegistryObject<Potion> HASTEPOTIONENHANCED = REGISTRY.register("hastepotionenhanced", () -> new Potion(new MobEffectInstance(MobEffects.DIG_SPEED, 1800, 1, false, true)));
	public static final RegistryObject<Potion> MININGFATIGUEPOTION = REGISTRY.register("miningfatiguepotion", () -> new Potion(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 1200, 1, false, true)));
	public static final RegistryObject<Potion> HEALTHBOOSTPOTION = REGISTRY.register("healthboostpotion", () -> new Potion(new MobEffectInstance(MobEffects.HEALTH_BOOST, 2400, 0, false, true)));
	public static final RegistryObject<Potion> HEALTHBOOSTPOTIONLONG = REGISTRY.register("healthboostpotionlong", () -> new Potion(new MobEffectInstance(MobEffects.HEALTH_BOOST, 4800, 0, false, true)));
	public static final RegistryObject<Potion> HEALTHBOOSTPOTIONENHANCED = REGISTRY.register("healthboostpotionenhanced", () -> new Potion(new MobEffectInstance(MobEffects.HEALTH_BOOST, 1800, 1, false, true)));
	public static final RegistryObject<Potion> NAUSEAPOTION = REGISTRY.register("nauseapotion", () -> new Potion(new MobEffectInstance(MobEffects.CONFUSION, 1800, 0, false, true)));
	public static final RegistryObject<Potion> NAUSEAPOTIONLONG = REGISTRY.register("nauseapotionlong", () -> new Potion(new MobEffectInstance(MobEffects.CONFUSION, 3600, 0, false, true)));
	public static final RegistryObject<Potion> SATURATIONPOTION = REGISTRY.register("saturationpotion", () -> new Potion(new MobEffectInstance(PotionRecipesModMobEffects.SATURATION.get(), 3600, 0, false, true)));
	public static final RegistryObject<Potion> SATURATIONPOTIONLONG = REGISTRY.register("saturationpotionlong", () -> new Potion(new MobEffectInstance(PotionRecipesModMobEffects.SATURATION.get(), 7200, 0, false, true)));
}
